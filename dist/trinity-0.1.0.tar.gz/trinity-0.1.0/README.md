# trinity

trinity is a command line tool for grabbing homework from Trinity School's assignment page. As such, it is intended to be used by Trinity students.

## Installation

Make sure you have python, pip, and brew.

### Unix / Macintosh

For the time being, try:
```
brew install npm
npm install phantom phantomjs -g
pip install https://github.com/WilliamChiu/trinity/zipball/master
```
